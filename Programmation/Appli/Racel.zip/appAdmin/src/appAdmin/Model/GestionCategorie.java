package appAdmin.Model;

import controller.ControleurAdministration;

public class GestionCategorie {
	public ControleurAdministration sonControleurAdministration;
	/** Methodes **/
	public void supprimerCategorie(int numCat) {
		
	}
	
	public void ajouterCategorie(String nomCat){
		
	}
	
	public void modifierCategorie(int numCat, String nomCat){
		
	}
	
}
